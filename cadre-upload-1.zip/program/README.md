# program/ — seat registry (Anchor)

Reference skeleton of the on-chain half of Cadre. It holds **no money**: no bond, no escrow, no payout, no pool.
It is the public record of the 20 seats and of what the rulebook did to them: §2/§3 assignment, §4 daily score
(with an inputs hash anyone can recompute), §5 replacement, §7 bans (3 of 5 committee signatures within 24 h,
permanent `BanRecord` per wallet) and §8 committee recall (11 of 20 seat holders), plus the §12 election result.
**`cargo check` passes; not audited, not deployed.**

```
anchor build          # needs solana 1.18+, anchor 0.30.1, rust 1.79+
anchor keys sync      # replaces the placeholder program id in lib.rs and Anchor.toml
anchor test           # tests/ to be written: assign_seat → propose_ban → approve_ban ×3 → execute_ban →
                      # assign_seat for the same wallet fails (Banned)
```

Design notes
- The pad has **no admin key** after `initialize`. Only the 5 committee members (3-of-5 within 24 h), the
  score oracle (publishes an inputs hash with every write) and public expiry can change state.
- A ban blocks the developer's wallet on chain (`BanRecord` PDA, seeds `["ban", wallet]`). Linked wallets named in
  the committee's evidence are blocked by the API (`banned_wallets`) from the same decision.
- A ban pays nothing out. Holders are never promised a payout, and no developer money is ever locked.
- Committee signatures for `mark_replaced` are collected off-chain into a Squads multisig transaction
  in v1; a native 3-of-5 `decide_challenge` is the planned follow-up.
