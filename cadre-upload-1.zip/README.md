# Cadre

A launchpad with twenty vetted developer seats. Scarcity creates attention, reputation builds trust,
competition drives quality. This repository is the product behind the public site: rulebook, scanner,
API, alert bot and the on-chain seat-registry program.

```
the-twenty/
├─ web/                 the site, standalone (head, OG image, live-API adapter)      ← deployable as is
├─ packages/shared/     rulebook as code: score, seasons, ballots' Merkle root    ✓ typechecked, tests pass
├─ packages/scanner/    the four pre-checks against Helius history + deployer index ✓ typechecked, fixture tests pass
├─ packages/api/        Fastify /v1 feeds, free scanner, slot-fee billing, Helius webhook, schema ✓ typechecked, schema parses
├─ packages/bot/        Telegram + webhook delivery of pad events                  ✓ typechecked
├─ program/             Anchor seat-registry program (reference, not audited)        ✓ cargo check passes
├─ infra/               docker-compose, Dockerfile, Railway config
└─ docs/                SPEC.md · API.md · GTM.md · COMPANY.md (entity, MiCA, KYC) · KPIS.md · BRAND.md · HELP.md · CHANGELOG.md
├─ web/brand/           the mark as standalone SVGs (stacked, mono, coin, emblem)
└─ web/icons/           PWA icons from the coin + emblem-1024.png · web/manifest.webmanifest
```

## Run it
```
cp .env.example .env            # add HELIUS_API_KEY, TELEGRAM_BOT_TOKEN
docker compose -f infra/docker-compose.yml up db     # Postgres with the schema applied
npm install && npm run build
npm test                        # 13 end-to-end scenarios on an in-process Postgres + security suite (no database needed)
npm run demo                    # the whole pad on this machine: http://localhost:8080 (docs/OPERATIONS.md → "Demo")
npm run devnet:check -- --env .env.devnet   # pre-flight for a devnet rehearsal (docs/DEVNET.md)
node web/build.mjs              # re-stamp the site's Content-Security-Policy after editing web/index.html
npm run dev:api                 # http://localhost:8080/v1/pad
npm run dev:jobs                # the scheduler (lifecycle, snapshots, scores, season, bans, billing)
npm run dev:bot
npm run scan -- <deployer-wallet>      # one-off scan from the CLI
npm -w @twenty/shared test             # Merkle (ballots) + scoring tests
npm -w @twenty/scanner test            # fixture tests for the four checks
```

## Revenue path
There are no subscriptions and no API keys. Revenue is the 3 SOL launch fee (50 % to the seat pool, 50 % to the treasury; paid in SOL with a `SLOT-…` memo, no card processor, no custody) and franchise licences. See docs/COMPANY.md before

## Status
What the preview shows is real UI over sample data. The server side here is a scaffold that type-checks
and encodes the rules; it has not run against mainnet traffic yet. Order of work: live scanner → public
vetting round → devnet season → audit → mainnet season 1 (docs/GTM.md).
